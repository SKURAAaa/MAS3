﻿namespace ZooManagement
{
    // Klasa bazowa
    public class Keeper
    {
        public string Name { get; set; }
        public int Experience { get; set; }

        public virtual void TakeCareOf(Animal animal)
        {
            Console.WriteLine($"{Name} is taking care of {animal.Name}");
        }
    }

    // Wielodziedziczenie poprzez interfejsy
    public interface ILionKeeper
    {
        void TakeCareOfLion(Lion lion);
    }

    public interface IEagleKeeper
    {
        void TakeCareOfEagle(Eagle eagle);
    }

    public interface IElephantKeeper
    {
        void TakeCareOfElephant(Elephant elephant);
    }

    public interface IPenguinKeeper
    {
        void TakeCareOfPenguin(Penguin penguin);
    }

    public class LionKeeper : Keeper, ILionKeeper
    {
        public override void TakeCareOf(Animal animal)
        {
            if (animal is Lion)
            {
                TakeCareOfLion((Lion)animal);
            }
            else
            {
                base.TakeCareOf(animal);
            }
        }

        public void TakeCareOfLion(Lion lion)
        {
            Console.WriteLine($"{Name} the lion keeper is taking special care of {lion.Name}");
        }
    }

    public class EagleKeeper : Keeper, IEagleKeeper
    {
        public override void TakeCareOf(Animal animal)
        {
            if (animal is Eagle)
            {
                TakeCareOfEagle((Eagle)animal);
            }
            else
            {
                base.TakeCareOf(animal);
            }
        }

        public void TakeCareOfEagle(Eagle eagle)
        {
            Console.WriteLine($"{Name} the eagle keeper is taking special care of {eagle.Name}");
        }
    }

    public class ElephantKeeper : Keeper, IElephantKeeper
    {
        public override void TakeCareOf(Animal animal)
        {
            if (animal is Elephant)
            {
                TakeCareOfElephant((Elephant)animal);
            }
            else
            {
                base.TakeCareOf(animal);
            }
        }

        public void TakeCareOfElephant(Elephant elephant)
        {
            Console.WriteLine($"{Name} the elephant keeper is taking special care of {elephant.Name}");
        }
    }

    public class PenguinKeeper : Keeper, IPenguinKeeper
    {
        public override void TakeCareOf(Animal animal)
        {
            if (animal is Penguin)
            {
                TakeCareOfPenguin((Penguin)animal);
            }
            else
            {
                base.TakeCareOf(animal);
            }
        }

        public void TakeCareOfPenguin(Penguin penguin)
        {
            Console.WriteLine($"{Name} the penguin keeper is taking special care of {penguin.Name}");
        }
    }

    // Overlapping
    public class OverlappedKeeper : Keeper
    {
        public override void TakeCareOf(Animal animal)
        {
            if (animal is Lion || animal is Eagle)
            {
                Console.WriteLine($"{Name} is taking care of both {animal.Name} the Lion and Eagle.");
            }
            else
            {
                base.TakeCareOf(animal);
            }
        }
    }
}
