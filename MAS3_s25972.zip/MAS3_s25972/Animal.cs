﻿namespace ZooManagement
{
    // Klasa abstrakcyjna / polimorfizm
    public abstract class Animal
    {
        public string Name { get; set; }
        public int Age { get; set; }

        public abstract void MakeSound();
    }

    public class Lion : Animal
    {
        public override void MakeSound()
        {
            Console.WriteLine($"{Name} the lion roars!");
        }
    }

    public class Eagle : Animal
    {
        public override void MakeSound()
        {
            Console.WriteLine($"{Name} the eagle screeches!");
        }
    }

    public class Elephant : Animal
    {
        public override void MakeSound()
        {
            Console.WriteLine($"{Name} the elephant trumpets!");
        }
    }

    public class Penguin : Animal
    {
        public override void MakeSound()
        {
            Console.WriteLine($"{Name} the penguin squawks!");
        }
    }
}