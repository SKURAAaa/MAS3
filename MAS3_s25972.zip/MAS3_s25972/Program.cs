﻿using System;

namespace ZooManagement
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the Zoo Management System!");

            // Tworzenie instancji zwierząt
            Animal lion = new Lion { Name = "Leo", Age = 5 };
            Animal eagle = new Eagle { Name = "Eddie", Age = 3 };
            Animal elephant = new Elephant { Name = "Ella", Age = 10 };
            Animal penguin = new Penguin { Name = "Penny", Age = 2 };

            // Tworzenie instancji zagrody
            Enclosure lionEnclosure = new Enclosure { Name = "Lion's Den", Size = 500 };
            Enclosure eagleEnclosure = new Enclosure { Name = "Eagle's Nest", Size = 300 };
            Enclosure elephantEnclosure = new Enclosure { Name = "Elephant's Park", Size = 1000 };
            Enclosure penguinEnclosure = new Enclosure { Name = "Penguin's Pool", Size = 400 };

            // Tworzenie instancji opiekunów
            LionKeeper lionKeeper = new LionKeeper { Name = "John", Experience = 10 };
            EagleKeeper eagleKeeper = new EagleKeeper { Name = "Alice", Experience = 8 };
            ElephantKeeper elephantKeeper = new ElephantKeeper { Name = "Sam", Experience = 15 };
            PenguinKeeper penguinKeeper = new PenguinKeeper { Name = "Emma", Experience = 5 };

            // Przypisywanie zwierząt do zagród
            lionEnclosure.AddAnimal(lion);
            eagleEnclosure.AddAnimal(eagle);
            elephantEnclosure.AddAnimal(elephant);
            penguinEnclosure.AddAnimal(penguin);

            // Wyświetlanie informacji
            lionKeeper.TakeCareOf(lion);
            eagleKeeper.TakeCareOf(eagle);
            elephantKeeper.TakeCareOf(elephant);
            penguinKeeper.TakeCareOf(penguin);

            // Przykład polimorfizmu
            lion.MakeSound();
            eagle.MakeSound();
            elephant.MakeSound();
            penguin.MakeSound();

            // Dynamiczne zmiany ról
            DynamicAnimal dynamicLion = new DynamicAnimal(lion);
            dynamicLion.ChangeRole(new Eagle { Name = "LeoEagle", Age = 5 });
            dynamicLion.CurrentRole.MakeSound();

            // Przykład overlapping
            Keeper overlappedKeeper = new OverlappedKeeper { Name = "Alex", Experience = 12 };
            overlappedKeeper.TakeCareOf(lion);
            overlappedKeeper.TakeCareOf(eagle);
        }
    }
}
