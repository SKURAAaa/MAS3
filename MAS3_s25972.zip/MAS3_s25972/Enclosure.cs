﻿using System.Collections.Generic;

namespace ZooManagement
{
    public class Enclosure
    {
        public string Name { get; set; }
        public double Size { get; set; }
        private List<Animal> Animals { get; set; } = new List<Animal>();

        public void AddAnimal(Animal animal)
        {
            Animals.Add(animal);
            Console.WriteLine($"{animal.Name} has been added to the {Name}");
        }
    }
}