﻿using System.Collections.Generic;

namespace ZooManagement
{
    public class Zoo
    {
        public string Name { get; set; }
        public string Location { get; set; }
        private List<Enclosure> Enclosures { get; set; } = new List<Enclosure>();

        public void AddEnclosure(Enclosure enclosure)
        {
            Enclosures.Add(enclosure);
            Console.WriteLine($"{enclosure.Name} has been added to the zoo");
        }
    }
}