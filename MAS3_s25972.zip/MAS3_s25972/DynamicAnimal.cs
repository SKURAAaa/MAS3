﻿namespace ZooManagement
{
    // Dynamiczne dziedziczenie
    public class DynamicAnimal
    {
        public Animal CurrentRole { get; private set; }

        public DynamicAnimal(Animal initialRole)
        {
            CurrentRole = initialRole;
        }

        public void ChangeRole(Animal newRole)
        {
            CurrentRole = newRole;
            Console.WriteLine($"Role changed to {newRole.GetType().Name}.");
        }
    }
}